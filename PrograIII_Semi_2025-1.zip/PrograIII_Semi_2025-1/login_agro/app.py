from flask import Flask, request, redirect, jsonify
from flask import render_template, session
import mysql.connector
import json
from datetime import datetime, timedelta
import random
import string
from openai import OpenAI
import os
import re

app = Flask(__name__)

# Nota: La clave secreta debe ser una cadena aleatoria compleja y almacenada de forma segura
app.secret_key = 'miclave123'

client = OpenAI(
    # La clave API proporcionada es un placeholder/ejemplo y debe ser reemplazada por una clave válida
    api_key='',
    base_url='https://api.groq.com/openai/v1'
)

def get_db():
    """Establece la conexión a la base de datos MySQL."""
    # Nota: Los parámetros de conexión son 'localhost', 'root', '' y 'agroquimica'
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="agroquimica"
    )

def generar_numero_recibo():
    """Genera un número de recibo único"""
    return 'R' + ''.join(random.choices(string.digits, k=8))

def obtener_productos_para_ia():
    """Obtiene todos los productos de la base de datos para el contexto de la IA"""
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT p.nombre, p.descripcion, c.nombre AS categoria, p.stok
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.stok > 0
    """)
    productos = cursor.fetchall()
    cursor.close()
    db.close()
    
    return productos

def obtener_productos_similares(consulta):
    """Busca productos similares a lo que el usuario está preguntando"""
    db = get_db()
    cursor = db.cursor(dictionary=True)
    
    # Buscar productos por nombre o categoría
    cursor.execute("""
        SELECT p.nombre, p.descripcion, c.nombre AS categoria, p.stok
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.stok > 0 AND (
            p.nombre LIKE %s OR 
            p.descripcion LIKE %s OR 
            c.nombre LIKE %s
        )
        LIMIT 5
    """, (f"%{consulta}%", f"%{consulta}%", f"%{consulta}%"))
    
    productos = cursor.fetchall()
    cursor.close()
    db.close()
    
    return productos

def formatear_productos_recomendados(productos):
    """Formatea los productos para mostrar en la respuesta"""
    if not productos:
        return "No tenemos productos específicos para esa necesidad. Te recomiendo revisar nuestros productos generales."
    
    texto = "🔹 **Productos disponibles:**\n"
    for prod in productos:
        stock_info = f" (Stock: {prod['stok']})" if prod['stok'] < 10 else ""
        texto += f"  • {prod['nombre']} ({prod['categoria']}){stock_info}: {prod['descripcion'][:80]}...\n"
    
    return texto

def limpiar_respuesta(texto):
    """Limpia el formato markdown y verifica productos mencionados"""
    if not texto:
        return texto
    
    # Obtener todos los productos reales
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT nombre FROM productos WHERE stok > 0")
    productos_reales = [p['nombre'].lower() for p in cursor.fetchall()]
    cursor.close()
    db.close()
    
    # Verificar productos mencionados (pero mantener el texto original)
    lineas = texto.split('\n')
    lineas_verificadas = []
    
    for linea in lineas:
        lineas_verificadas.append(linea)
    
    texto = '\n'.join(lineas_verificadas)
    
    # Limpieza básica de formato
    texto = texto.replace('**', '').replace('```', '').replace('`', '')
    texto = re.sub(r'\s+', ' ', texto)
    
    return texto

def inicializar_chat():
    """Función para inicializar el historial del chat con la instrucción del sistema."""
    
    # Obtener productos disponibles
    productos = obtener_productos_para_ia()
    
    # Formatear productos para el contexto
    productos_formateados = []
    for prod in productos:
        productos_formateados.append(f"- {prod['nombre']} ({prod['categoria']}): {prod['descripcion'][:100]}...")
    
    productos_info = "\n".join(productos_formateados) if productos_formateados else "No hay productos disponibles en este momento."
    
    return [
        {"role": "system", "content": f"""Eres AGRO-ASIST, un especialista en agroquímica con 20 años de experiencia.

📋 PRODUCTOS DISPONIBLES EN LA TIENDA:
{productos_info}

REGLAS IMPORTANTES:
1. SOLO puedes recomendar productos que estén en la lista de arriba
2. NO inventes productos ni nombres que no existan en nuestra tienda
3. Si el usuario pregunta por algo que no tenemos, sugiere alternativas de lo que SÍ tenemos
4. Siempre menciona la categoría del producto cuando hagas recomendaciones
5. Si no tenemos stock de algo, NO lo recomiendes
6. Si el stock es bajo (<10 unidades), menciónalo en la recomendación

INSTRUCCIONES DE FORMATO:

1. ORGANIZA las respuestas con secciones claras
2. USA este formato exacto:

   🔹 **Sección 1:** [Título breve]
     • Punto 1: [Descripción clara]
     • Punto 2: [Descripción clara]

   🔹 **Sección 2:** [Título breve]
     • Punto 1: [Descripción clara]

3. NO uses tablas, markdown complejo o caracteres especiales
4. SEPARA las secciones con una línea en blanco
5. MÁXIMO 3-4 puntos por sección
6. Sé conciso pero informativo
7. Siempre incluye la sección "Productos recomendados" si hay productos relevantes

EJEMPLO DE FORMATO CORRECTO:

🔹 **Productos recomendados:**
  • Fertilizante NPK Balance (Fertilizantes): Abono granulado de liberación lenta
  • Fungicida Systemic Pro (Fungicidas): Ideal para el control de mildiu y royas

🔹 **Instrucciones de uso:**
  • Dosificación: 10ml por litro
  • Frecuencia: Cada 7 días
  • Precaución: Usar equipo de protección

🔹 **Alternativas disponibles:**
  • [Nombre de producto alternativo] ([Categoría]): [Breve descripción]"""}
    ]

@app.route('/')
def index():
    """Ruta principal que redirige al login."""
    session.clear()
    return redirect('/login')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Ruta para el inicio de sesión."""
    mensaje = ''
    if request.method == 'POST':
        usuario = request.form.get('usuario', '').strip()
        contrasena = request.form.get('contrasena', '')
        # Validar entrada básica
        if not usuario or not contrasena:
            mensaje = 'Por favor ingrese usuario y contraseña'
            return render_template('login.html', mensaje=mensaje)
        db = get_db()
        cursor = db.cursor(dictionary=True)
        # Consulta para autenticar
        cursor.execute("SELECT * FROM usuarios WHERE usuario = %s AND contrasena = %s", (usuario, contrasena))
        user = cursor.fetchone()
        cursor.close()
        db.close()
        if user:
            session['usuario'] = usuario
            session['rol'] = user['rol']
            # Inicializar historial de chat al hacer login
            session['chat_history'] = inicializar_chat()
            return redirect('/menu')
        else:
            mensaje = 'Usuario o contraseña incorrectos'
            return render_template('login.html', mensaje=mensaje)
    else:
        return render_template('login.html', mensaje=mensaje)

@app.route('/menu')
def menu():
    """Ruta del menú principal, requiere autenticación."""
    if 'usuario' not in session:
        return redirect('/login')
    return render_template('menu.html',
    usuario=session['usuario'], rol=session.get('rol'))

@app.route('/productos')
def productos():
    """Muestra la lista de productos y categorías."""
    if 'usuario' not in session:
        return redirect('/login')
    db = get_db()
    cursor = db.cursor(dictionary=True)
    
    # Obtener productos con nombre de categoría
    cursor.execute("""
        SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria, p.categoria_id
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
    """)
    productos = cursor.fetchall()
    
    # Obtener categorías para el formulario
    cursor.execute("SELECT * FROM categorias")
    categorias = cursor.fetchall()
    cursor.close()
    db.close()
    
    return render_template(
        'productos.html',
        usuario=session['usuario'],
        rol_usuario=session.get('rol'),
        productos=productos,
        categorias=categorias
    )

@app.route('/productos/agregar', methods=['POST'])
def agregar_producto():
    """Agrega un nuevo producto a la base de datos."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    if session.get('rol') not in ['administrador', 'vendedor']:
        return jsonify({"success": False, "error": "No tiene permiso para agregar"})
    # Recolección de datos
    nombre = request.form['nombre']
    descripcion = request.form['descripcion']
    categoria_id = request.form['categoria']
    precio = request.form['precio']
    stok = request.form['stok']
    icono = request.form['icono']
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        INSERT INTO productos (nombre, descripcion, categoria_id, precio, stok, icono)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (nombre, descripcion, categoria_id, precio, stok, icono))
    db.commit()
    # Obtener lista actualizada para el frontend
    cursor.execute("""
        SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
    """)
    productos = cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify({"success": True, "productos": productos})

@app.route('/productos/modificar/<int:id>', methods=['POST'])
def modificar_producto(id):
    """Modifica un producto existente."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    if session.get('rol') not in ['administrador', 'vendedor']:
        return jsonify({"success": False, "error": "No tiene permiso para modificar"})
    # Recolección de datos
    nombre = request.form['nombre']
    descripcion = request.form['descripcion']
    categoria_id = request.form['categoria']
    precio = request.form['precio']
    stok = request.form['stok']
    icono = request.form['icono']
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        UPDATE productos
        SET nombre=%s, descripcion=%s, categoria_id=%s, precio=%s, stok=%s, icono=%s
        WHERE id=%s
    """, (nombre, descripcion, categoria_id, precio, stok, icono, id))
    db.commit()
    # Obtener lista actualizada para el frontend
    cursor.execute("""
        SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
    """)
    productos = cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify({"success": True, "productos": productos})

@app.route('/productos/eliminar/<int:id>', methods=['POST'])
def eliminar_producto(id):
    """Elimina un producto existente."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    if session.get('rol') != 'administrador':
        return jsonify({"success": False, "error": "Solo el administrador puede eliminar"})
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("DELETE FROM productos WHERE id=%s", (id,))
    db.commit()
    # Obtener lista actualizada para el frontend
    cursor.execute("""
        SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
    """)
    productos = cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify({"success": True, "productos": productos})

@app.route('/productos/detalle/<int:id>')
def detalle_producto(id):
    """Muestra la vista de detalle de un producto."""
    if 'usuario' not in session:
        return redirect('/login')
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("""
        SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria
        FROM productos p
        LEFT JOIN categorias c ON p.categoria_id = c.id
        WHERE p.id=%s
    """, (id,))
    producto = cursor.fetchone()
    cursor.close()
    db.close()
    if not producto:
        return "Producto no encontrado", 404
    return render_template('detalle.html', producto=producto,
    rol=session.get('rol'))

@app.route('/compras/finalizar', methods=['POST'])
def finalizar_compra():
    """Procesa la compra, guarda el recibo y actualiza el stock."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    
    # Solo usuarios y vendedores pueden comprar
    if session.get('rol') not in ['usuario', 'vendedor']:
        return jsonify({"success": False, "error": "No tiene permiso para realizar compras"})
    try:
        data = request.get_json()
        carrito = data.get('carrito', [])
        total = data.get('total', 0)
        
        if not carrito:
            return jsonify({"success": False, "error": "Carrito vacío"})
        db = get_db()
        cursor = db.cursor(dictionary=True)
        
        # 1. Verificar stock antes de procesar la compra
        for item in carrito:
            cursor.execute("SELECT stok FROM productos WHERE id = %s", (item['id'],))
            producto = cursor.fetchone()
            if not producto:
                db.close()
                return jsonify({"success": False, "error": f"Producto {item['nombre']} no encontrado"})
            if producto['stok'] < item['cantidad']:
                db.close()
                return jsonify({"success": False, "error": f"Stock insuficiente para {item['nombre']}. Stock disponible: {producto['stok']}"})
        # 2. Generar número de recibo
        numero_recibo = generar_numero_recibo()
        
        # 3. Guardar recibo
        cursor.execute("""
            INSERT INTO recibos (numero_recibo, total, items, usuario, estado)
            VALUES (%s, %s, %s, %s, 'completado')
        """, (numero_recibo, total, json.dumps(carrito), session['usuario']))
        
        # 4. Actualizar stock de productos
        for item in carrito:
            cursor.execute("""
                UPDATE productos
                SET stok = stok - %s
                WHERE id = %s
            """, (item['cantidad'], item['id']))
        
        db.commit()
        
        # 5. Obtener productos actualizados para el frontend
        cursor.execute("""
            SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria, p.categoria_id
            FROM productos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
        """)
        productos_actualizados = cursor.fetchall()
        
        cursor.close()
        db.close()
        
        return jsonify({
            "success": True,
            "numero_recibo": numero_recibo,
            "productos": productos_actualizados
        })
        
    except Exception as e:
        # En caso de error, intenta hacer rollback si es necesario (aunque commit explícito se maneja arriba)
        return jsonify({"success": False, "error": str(e)})

@app.route('/compras/historial')
def historial_compras():
    """Muestra el historial de compras del usuario o todas las compras para el admin."""
    if 'usuario' not in session:
        return redirect('/login')
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    
    # Obtener parámetros de filtro
    filtro_nombre = request.args.get('filtro_nombre', '')
    filtro_fecha = request.args.get('filtro_fecha', '')
    filtro_estado = request.args.get('filtro_estado', 'todos')
    
    # Construir consulta base (filtrado por usuario para roles no admin)
    if session.get('rol') == 'administrador':
        query = "SELECT * FROM recibos WHERE 1=1"
        params = []
    else:
        query = "SELECT * FROM recibos WHERE usuario = %s"
        params = [session['usuario']]
    
    # Aplicar filtros
    if filtro_nombre:
        query += " AND numero_recibo LIKE %s"
        params.append(f'%{filtro_nombre}%')
    
    if filtro_fecha:
        query += " AND DATE(fecha) = %s"
        params.append(filtro_fecha)
    
    if filtro_estado != 'todos':
        query += " AND estado = %s"
        params.append(filtro_estado)
    
    query += " ORDER BY fecha DESC"
    
    cursor.execute(query, params)
    recibos = cursor.fetchall()
    cursor.close()
    db.close()
    
    # Parsear items JSON
    recibos_procesados = []
    for recibo in recibos:
        try:
            recibo_procesado = dict(recibo)
            # El campo 'items' es un string JSON que debe ser parseado
            recibo_procesado['items_data'] = json.loads(recibo['items'])
            recibos_procesados.append(recibo_procesado)
        except Exception as e:
            print(f"Error parseando items del recibo {recibo['numero_recibo']}: {e}")
            recibo_procesado = dict(recibo)
            recibo_procesado['items_data'] = []
            recibos_procesados.append(recibo_procesado)
    
    return render_template('historial_compras.html',
                          recibos=recibos_procesados,
                          usuario=session['usuario'],
                          rol=session.get('rol'),
                          filtro_nombre=filtro_nombre,
                          filtro_fecha=filtro_fecha,
                          filtro_estado=filtro_estado)

@app.route('/compras/cancelar/<string:numero_recibo>', methods=['POST'])
def cancelar_compra(numero_recibo):
    """Permite al administrador cancelar una compra y restaurar el stock."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    
    # SOLO administradores pueden cancelar compras en esta implementación
    if session.get('rol') != 'administrador':
        return jsonify({"success": False, "error": "Solo los administradores pueden cancelar compras"})
    
    try:
        data = request.get_json()
        motivo_cancelacion = data.get('motivo_cancelacion', '').strip()
        
        if not motivo_cancelacion:
            return jsonify({"success": False, "error": "Debe proporcionar un motivo de cancelación"})
        
        db = get_db()
        cursor = db.cursor(dictionary=True)
        
        # 1. Verificar que el recibo existe
        cursor.execute("SELECT * FROM recibos WHERE numero_recibo = %s", (numero_recibo,))
        recibo = cursor.fetchone()
        
        if not recibo:
            db.close()
            return jsonify({"success": False, "error": "Recibo no encontrado"})
        
        # 2. Verificar que el recibo no esté ya cancelado
        if recibo.get('estado') == 'cancelado':
            db.close()
            return jsonify({"success": False, "error": "El recibo ya está cancelado"})
        
        # 3. Verificar límite de 24 horas (lógica opcional)
        fecha_recibo = recibo['fecha']
        # Convertir a objeto datetime si es necesario
        if isinstance(fecha_recibo, str):
            fecha_recibo = datetime.strptime(fecha_recibo, '%Y-%m-%d %H:%M:%S')
        
        limite_cancelacion = datetime.now() - timedelta(hours=24)
        if fecha_recibo < limite_cancelacion:
            db.close()
            return jsonify({"success": False, "error": "No se puede cancelar una compra después de 24 horas"})
        
        # 4. Parsear items del recibo
        items = json.loads(recibo['items'])
        
        # 5. Restaurar stock de productos
        for item in items:
            cursor.execute("""
                UPDATE productos
                SET stok = stok + %s
                WHERE id = %s
            """, (item['cantidad'], item['id']))
        
        # 6. Marcar recibo como cancelado con el motivo
        cursor.execute("""
            UPDATE recibos
            SET estado = 'cancelado', motivo_cancelacion = %s
            WHERE numero_recibo = %s
        """, (motivo_cancelacion, numero_recibo))
        
        db.commit()
        
        # 7. Obtener productos actualizados para el frontend
        cursor.execute("""
            SELECT p.id, p.nombre, p.descripcion, p.precio, p.stok, p.icono, c.nombre AS categoria, p.categoria_id
            FROM productos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
        """)
        productos_actualizados = cursor.fetchall()
        
        cursor.close()
        db.close()
        
        return jsonify({
            "success": True,
            "mensaje": "Compra cancelada exitosamente. El stock ha sido restaurado.",
            "productos": productos_actualizados
        })
        
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

@app.route('/logout')
def logout():
    """Cierra la sesión del usuario."""
    session.clear()
    return redirect('/login')

@app.route('/categorias')
def categorias():
    """Muestra la gestión de categorías."""
    if 'usuario' not in session:
        return redirect('/login')
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM categorias")
    categorias = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('categorias.html', categorias=categorias,
    usuario=session['usuario'], rol=session.get('rol'))

@app.route('/categorias/agregar', methods=['POST'])
def agregar_categoria():
    """Agrega una nueva categoría."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    if session.get('rol') != 'administrador':
        return jsonify({"success": False, "error": "Solo el administrador puede agregar categorías"})
    
    nombre = request.form['nombre']
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("INSERT INTO categorias (nombre) VALUES (%s)", (nombre,))
    db.commit()
    cursor.close()
    db.close()
    return jsonify({"success": True})

@app.route('/registro', methods=['GET', 'POST'])
def registro():
    """Ruta para el registro de nuevos usuarios (rol 'usuario')."""
    mensaje = ''
    exito = ''
    if request.method == 'POST':
        usuario = request.form['usuario'].strip()
        contrasena = request.form['contrasena']
        confirmar = request.form['confirmar']
        # Datos de usuario_detalle
        nombre_completo = request.form['nombre_completo']
        direccion = request.form['direccion']
        correo = request.form['correo']
        telefono = request.form['telefono']
        dui = request.form['dui']
        fecha_nacimiento = request.form['fecha_nacimiento']
        if contrasena != confirmar:
            mensaje = "Las contraseñas no coinciden"
            return render_template('registro.html', mensaje=mensaje)
        db = get_db()
        cursor = db.cursor(dictionary=True)
        # Verificar si ya existe el usuario
        cursor.execute("SELECT * FROM usuarios WHERE usuario=%s", (usuario,))
        existe = cursor.fetchone()
        if existe:
            mensaje = "El usuario ya existe"
            cursor.close()
            db.close()
            return render_template('registro.html', mensaje=mensaje)
        # Insertar usuario en tabla 'usuarios' con rol 'usuario'
        cursor.execute("""
            INSERT INTO usuarios (usuario, contrasena, rol)
            VALUES (%s, %s, %s)
        """, (usuario, contrasena, 'usuario'))
        db.commit()
        # Obtener ID del usuario insertado
        id_usuario = cursor.lastrowid
        # Insertar detalle en tabla 'usuarios_detalle'
        cursor.execute("""
            INSERT INTO usuarios_detalle
            (id_usuario, nombre_completo, direccion, correo, telefono, dui, fecha_nacimiento)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (id_usuario, nombre_completo, direccion, correo, telefono, dui, fecha_nacimiento))
        db.commit()
        cursor.close()
        db.close()
        exito = "Cuenta creada correctamente."
        return render_template('registro.html', exito=exito)
    return render_template('registro.html')

@app.route('/categorias/eliminar/<int:id>', methods=['POST'])
def eliminar_categoria(id):
    """Elimina una categoría."""
    if 'usuario' not in session:
        return jsonify({"success": False, "error": "No autorizado"})
    if session.get('rol') != 'administrador':
        return jsonify({"success": False, "error": "Solo el administrador puede eliminar categorías"})
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    # Nota: Es crucial manejar la integridad referencial para productos antes de eliminar una categoría.
    cursor.execute("DELETE FROM categorias WHERE id=%s", (id,))
    db.commit()
    cursor.execute("SELECT * FROM categorias")
    categorias = cursor.fetchall()
    cursor.close()
    db.close()
    return jsonify({"success": True, "categorias": categorias})

@app.route('/registrar_vendedor_admin', methods=['GET', 'POST'])
def registrar_vendedor_admin():
    """Ruta para registrar nuevos administradores o vendedores (desde el admin)."""
    if request.method == 'GET':
        return render_template('registrar_vendedor_admin.html')
    # ------------ DATOS GENERALES DEL USUARIO ------------
    usuario = request.form['usuario']
    clave = request.form['clave']
    rol = request.form['rol']  # administrador o vendedor
    nombre_completo = request.form['nombre_completo']
    direccion = request.form.get('direccion')
    correo = request.form.get('correo')
    telefono = request.form.get('telefono')
    dui = request.form.get('dui')
    fecha_nacimiento = request.form.get('fecha_nacimiento')
    # ------------ DATOS EXCLUSIVOS ------------
    cargo = request.form.get('cargo')
    salario = request.form.get('salario')
    sueldo = request.form.get('sueldo')
    fecha_contratacion = request.form.get('fecha_contratacion')
    comision = request.form.get('comision')
    db = get_db()
    cursor = db.cursor(dictionary=True)
    # 1️⃣ INSERTAR EN TABLA USUARIOS
    cursor.execute("""
        INSERT INTO usuarios (usuario, contrasena, rol)
        VALUES (%s, %s, %s)
    """, (usuario, clave, rol))
    db.commit()
    id_usuario = cursor.lastrowid  # ID para tabla hija
    # 2️⃣ INSERTAR SEGÚN EL ROL
    if rol == "administrador":
        cursor.execute("""
            INSERT INTO administradores_info (
                id_usuario, nombre_completo, direccion, correo, telefono,
                dui, fecha_nacimiento, cargo, salario
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            id_usuario, nombre_completo, direccion, correo, telefono,
            dui, fecha_nacimiento, cargo, salario
        ))
    elif rol == "vendedor":
        cursor.execute("""
            INSERT INTO vendedores_info (
                id_usuario, nombre_completo, direccion, correo, telefono,
                dui, fecha_nacimiento, sueldo, fecha_contratacion, comision
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            id_usuario, nombre_completo, direccion, correo, telefono,
            dui, fecha_nacimiento, sueldo, fecha_contratacion, comision
        ))
    db.commit()
    cursor.close()
    db.close()
    return redirect('/menu')

# RUTA CORREGIDA PARA EL CHAT IA
@app.route('/asistente-ia', methods=['GET', 'POST'])  # CAMBIADO A GUION
def asistente_ia():
    """Ruta para interactuar con el asistente de IA especializado en agroquímica."""
    if 'usuario' not in session:
        return redirect('/login')
    
    # Inicializar historial si no existe
    if 'chat_history' not in session:
        session['chat_history'] = inicializar_chat()
    
    # Mensaje de bienvenida inicial (solo si solo tiene el mensaje del sistema)
    if len(session['chat_history']) == 1:
        # Obtener categorías disponibles
        db = get_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT DISTINCT nombre FROM categorias")
        categorias = cursor.fetchall()
        cursor.close()
        db.close()
        
        categorias_lista = ", ".join([cat['nombre'] for cat in categorias])
        
        # Obtener conteo de productos
        productos = obtener_productos_para_ia()
        
        mensaje_bienvenida = {
            "role": "assistant",
            "content": f"""¡Hola! Soy AGRO-ASIST, tu asistente especializado en agroquímica. 

🏪 **INFORMACIÓN DE LA TIENDA:**
• Productos disponibles: {len(productos)}
• Categorías: {categorias_lista}

📋 **Puedo ayudarte con:**
• Recomendaciones de productos específicos que tenemos en stock
• Información sobre fertilizantes, herbicidas, fungicidas
• Asesoría sobre control de plagas y enfermedades
• Dosificación y aplicación de productos

⚠️ **IMPORTANTE:** Solo recomendaré productos que realmente tengamos en nuestra tienda y que estén en stock.

¿En qué puedo asistirte hoy?"""
        }
        
        session['chat_history'].append(mensaje_bienvenida)
        session.modified = True
    
    if request.method == 'POST':
        pregunta = request.form['pregunta'].strip()
        
        if pregunta:  # Solo procesar si hay texto
            # Agregar pregunta del usuario al historial
            session['chat_history'].append({"role": "user", "content": pregunta})
            
            try:
                # Buscar productos relevantes para el contexto
                productos_relevantes = obtener_productos_similares(pregunta)
                
                # Preparar contexto adicional con productos
                contexto_productos = ""
                if productos_relevantes:
                    contexto_productos = "\n\n📦 PRODUCTOS DISPONIBLES RELACIONADOS:\n"
                    for prod in productos_relevantes[:3]:  # Mostrar máximo 3
                        stock_info = f" (Stock bajo: {prod['stok']})" if prod['stok'] < 5 else ""
                        contexto_productos += f"- {prod['nombre']} ({prod['categoria']}){stock_info}: {prod['descripcion'][:80]}...\n"
                
                # Obtener todos los productos para contexto general
                todos_productos = obtener_productos_para_ia()
                productos_info = "\n".join([f"- {p['nombre']} ({p['categoria']})" for p in todos_productos[:10]])
                
                # Crear mensaje del sistema con contexto actualizado
                mensaje_sistema = {
                    "role": "system",
                    "content": f"""Eres AGRO-ASIST, especialista en agroquímica. 

REGLAS ESTRICTAS:
1. SOLO puedes recomendar productos que estén en nuestra base de datos
2. NO inventes nombres de productos
3. Si no tenemos exactamente lo que piden, sugiere alternativas SIMILARES que SÍ tengamos
4. Si no tenemos nada relacionado, di claramente "No tenemos productos específicos para esa necesidad"
5. Verifica el stock antes de recomendar

NUESTROS PRODUCTOS:
{productos_info}

CONTEXTO ACTUAL:{contexto_productos}

Usuario pregunta: {pregunta}

FORMATO DE RESPUESTA OBLIGATORIO:
🔹 **Productos recomendados:** (SOLO si hay productos relevantes)
  • [Nombre producto] ([Categoría]): [Breve descripción]

🔹 **Instrucciones:**
  • Punto claro y conciso

🔹 **Alternativas disponibles:** (Si no hay el producto exacto)
  • [Producto similar] ([Categoría]): [Por qué es buena alternativa]"""
                }
                
                # Preparar historial para la IA (últimos 4 mensajes + sistema)
                historial_para_ia = [mensaje_sistema] + session['chat_history'][-4:]
                
                # Llamar a Groq/OpenAI
                response = client.chat.completions.create(
                    model="llama-3.1-8b-instant",
                    messages=historial_para_ia,
                    max_tokens=600,
                    temperature=0.7
                )
                
                respuesta = response.choices[0].message.content
                
                # Limpiar formato
                respuesta_limpia = limpiar_respuesta(respuesta)
                
                # Agregar nota si no hay productos relevantes
                if not productos_relevantes and any(palabra in pregunta.lower() for palabra in ['producto', 'recomienda', 'necesito', 'busco', 'tienes']):
                    respuesta_limpia += "\n\n💡 **Nota:** No tenemos productos específicos para esa solicitud. Te invito a revisar todas nuestras categorías disponibles o preguntar por algo más general."
                
                # Verificar que se mencionen productos reales
                productos_reales = [p['nombre'].lower() for p in todos_productos]
                palabras_respuesta = respuesta_limpia.lower().split()
                
                # Agregar respuesta al historial
                session['chat_history'].append({"role": "assistant", "content": respuesta_limpia})
                
            except Exception as e:
                error_msg = f"❌ Lo siento, hubo un error al procesar tu pregunta. Por favor, intenta de nuevo."
                session['chat_history'].append({"role": "assistant", "content": error_msg})
                print(f"ERROR en asistente IA: {e}")
            
            # Guardar cambios en la sesión
            session.modified = True
    
    return render_template('asistente_ia.html',
                          usuario=session['usuario'],
                          rol=session.get('rol'),
                          chat_history=session.get('chat_history', []))

@app.route('/limpiar-chat', methods=['POST'])
def limpiar_chat():
    """Reinicia el historial de conversación del asistente de IA."""
    if 'usuario' not in session:
        return jsonify({"success": False})
    
    # Reiniciar el historial del chat
    session['chat_history'] = inicializar_chat()
    
    # Agregar mensaje de bienvenida inicial
    # Obtener categorías disponibles
    db = get_db()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT DISTINCT nombre FROM categorias")
    categorias = cursor.fetchall()
    cursor.close()
    db.close()
    
    categorias_lista = ", ".join([cat['nombre'] for cat in categorias])
    
    productos = obtener_productos_para_ia()
    
    mensaje_bienvenida = {
        "role": "assistant",
        "content": f"""¡Conversación reiniciada! Soy AGRO-ASIST, tu asistente especializado en agroquímica. 

🏪 **INFORMACIÓN ACTUALIZADA:**
• Productos en stock: {len(productos)}
• Categorías disponibles: {categorias_lista}

¿En qué puedo ayudarte hoy? Recuerda que solo recomendaré productos que realmente tengamos disponibles."""
    }
    
    session['chat_history'].append(mensaje_bienvenida)
    session.modified = True
    
    return jsonify({"success": True})

# Nueva API para sugerencias de productos
@app.route('/api/productos-sugeridos', methods=['GET'])
def productos_sugeridos():
    """API para obtener productos sugeridos basados en una consulta"""
    if 'usuario' not in session:
        return jsonify({"error": "No autorizado"}), 401
    
    consulta = request.args.get('q', '')
    if not consulta:
        return jsonify({"productos": []})
    
    productos = obtener_productos_similares(consulta)
    return jsonify({"productos": productos})


#Analisis de ventas con IA
@app.route("/analisis_ventas_ia")
def analisis_ventas_ia():
    return render_template("analisis_ventas_ia.html")


@app.route("/analizar_ventas_ia", methods=["POST"])
def analizar_ventas_ia():
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)

        # Obtener todas las ventas activas
        cursor.execute("SELECT * FROM recibos")
        ventas = cursor.fetchall()

        # Obtener todos los items de ventas
        cursor.execute("SELECT * FROM recibos")
        items = cursor.fetchall()

        # Obtener productos
        cursor.execute("SELECT id, nombre, precio, stok FROM productos")
        productos = cursor.fetchall()

        # Obtener usuarios (vendedores)
        cursor.execute("SELECT id, usuario FROM usuarios")
        usuarios = cursor.fetchall()

        # Preparar los datos para la IA
        resumen = {
            "recibos": ventas,
            "recibos": items,
            "productos": productos,
            "usuarios": usuarios
        }

        # Llamada a OpenAI
        completion = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[
                {
                    "role": "system",
                    "content": 
                    "Eres un analista experto en ventas. Recibirás datos reales "
                    "y debes generar un análisis completo, claro y profesional. "
                    "Incluye: productos más vendidos, tendencias, ventas por semana "
                    "y mes, vendedores destacados, productos a punto de agotarse, "
                    "cancelaciones si existen, predicciones y recomendaciones."
                },
                {
                    "role": "user",
                      "content": json.dumps(resumen, default=str) 
                }
            ]
        )

        analisis = completion.choices[0].message.content


        return jsonify({
            "success": True,
            "analisis": analisis
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)})




# GRAFICAS
# --- RUTAS NUEVAS PARA DATOS DE GRÁFICAS (Chart.js) ---
@app.route("/analisis_datos", methods=["GET"])
def analisis_datos():
    """
    Devuelve JSON con los datos agregados necesarios para las gráficas:
      - productos más vendidos (labels, cantidades)
      - ventas por día (últimos 14 días)
      - participación por categoría (labels, valores)
    """
    try:
        db = get_db()
        cursor = db.cursor(dictionary=True)

        # Traer recibos completados
        cursor.execute("SELECT id, fecha, total, items, estado FROM recibos ORDER BY fecha DESC")
        recibos = cursor.fetchall()

        # Traer productos (id -> nombre, categoria)
        cursor.execute("""
            SELECT p.id, p.nombre, p.precio, p.stok, c.nombre AS categoria
            FROM productos p
            LEFT JOIN categorias c ON p.categoria_id = c.id
        """)
        productos = cursor.fetchall()

        cursor.close()
        db.close()

        # Mapeos rápidos
        prod_map = {p['id']: p for p in productos}
        prod_name_map = {p['id']: p['nombre'] for p in productos}
        prod_cat_map = {p['id']: p.get('categoria') or 'Sin categoría' for p in productos}

        # Agregados
        productos_vendidos = {}   # id_producto -> cantidad total vendida
        categoria_totales = {}    # categoria -> total vendido (monto)
        ventas_por_dia = {}       # 'YYYY-MM-DD' -> total vendido

        # Solo consideramos recibos completados para la mayoría de gráficas
        for r in recibos:
            try:
                # items puede venir como string JSON
                items = json.loads(r['items']) if isinstance(r['items'], str) else r['items']
            except Exception:
                items = []
            # Si estado no es 'completado' igual lo tomamos solo para cancelaciones u otra sección
            if r.get('estado') == 'completado':
                # Ventas por día (usar fecha)
                fecha = r.get('fecha')
                # convertir a str si es datetime
                dia = str(fecha.date()) if hasattr(fecha, 'date') else str(fecha)[:10]
                ventas_por_dia[dia] = ventas_por_dia.get(dia, 0) + float(r.get('total') or 0)

                # Items
                for it in items:
                    # los items pueden venir con clave 'id' o 'producto' dependiendo de tu app
                    prod_id = it.get('id') if isinstance(it, dict) and 'id' in it else None
                    cantidad = int(it.get('cantidad', 0)) if isinstance(it, dict) else 0
                    precio = float(it.get('precio', 0)) if isinstance(it, dict) else 0

                    # Sumar por producto (si tenemos id)
                    if prod_id:
                        productos_vendidos[prod_id] = productos_vendidos.get(prod_id, 0) + cantidad
                        # categoria
                        categoria = prod_cat_map.get(prod_id, 'Sin categoría')
                        categoria_totales[categoria] = categoria_totales.get(categoria, 0.0) + (precio * cantidad)
                    else:
                        # si no hay id, intentar usar nombre
                        nombre = it.get('nombre') if isinstance(it, dict) else None
                        key = f"noid::{nombre}"
                        productos_vendidos[key] = productos_vendidos.get(key, 0) + cantidad
                        categoria_totales['Sin categoría'] = categoria_totales.get('Sin categoría', 0.0) + (precio * cantidad)

        # Preparar top productos (ordenar por cantidad)
        top_list = []
        for pid, qty in productos_vendidos.items():
            label = prod_name_map.get(pid, pid if isinstance(pid, str) else f"Producto {pid}")
            top_list.append({"label": label, "cantidad": qty})
        top_list = sorted(top_list, key=lambda x: x['cantidad'], reverse=True)[:12]  # top12

        # Preparar datos para categorias
        cat_labels = list(categoria_totales.keys())
        cat_values = [round(categoria_totales[k], 2) for k in cat_labels]

        # Preparar ventas por día (últimos 14 días ordenados asc)
        # Asegurar que las fechas estén en rango de últimos 14 días (incluir días sin ventas)
        from datetime import datetime, timedelta
        hoy = datetime.now().date()
        dias = [(hoy - timedelta(days=i)).isoformat() for i in range(13, -1, -1)]  # 14 días
        ventas_dias_labels = dias
        ventas_dias_values = [round(ventas_por_dia.get(d, 0), 2) for d in dias]

        response = {
            "success": True,
            "productos_top": top_list,
            "categorias": {"labels": cat_labels, "values": cat_values},
            "ventas_por_dia": {"labels": ventas_dias_labels, "values": ventas_dias_values}
        }

        return jsonify(response)

    except Exception as e:
        return jsonify({"success": False, "error": str(e)})

if __name__ == '__main__':  # CORREGIDO: comillas simples
    # Ejecuta la aplicación en modo debug
    app.run(debug=True)